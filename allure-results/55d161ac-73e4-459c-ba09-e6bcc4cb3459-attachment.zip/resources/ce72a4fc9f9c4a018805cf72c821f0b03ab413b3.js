/*!
	TourTip 1.0.7 - 2014-05-21
	jQuery Help and Tour Layout
	(c) 2014, http://tinytools.codesells.com
	license: http://www.opensource.org/licenses/mit-license.php
*/


(function (jQuery, document, window) {
	var tourTipVars = localStorage.getItem('tourtip-vars');
	if (tourTipVars != null) {
		var tourTipVarsParsed = JSON.parse(tourTipVars);
		tourTip = tourTipVarsParsed['tourtip'];
	} else {
		tourTip = 'tourTip';
	}
	var tourTipCurrentIndex = -1;
	var tourTipObjects = new Array();
	var tourTipGeneralSettings;
	var BrowserDetect = {
		init: function () {
			this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
			this.version = this.searchVersion(navigator.userAgent)
				|| this.searchVersion(navigator.appVersion)
				|| "an unknown version";
			this.OS = this.searchString(this.dataOS) || "an unknown OS";
		},
		searchString: function (data) {
			for (var i = 0; i < data.length; i++) {
				var dataString = data[i].string;
				var dataProp = data[i].prop;
				this.versionSearchString = data[i].versionSearch || data[i].identity;
				if (dataString) {
					if (dataString.indexOf(data[i].subString) != -1)
						return data[i].identity;
				}
				else if (dataProp)
					return data[i].identity;
			}
		},
		searchVersion: function (dataString) {
			var index = dataString.indexOf(this.versionSearchString);
			if (index == -1) return;
			return parseFloat(dataString.substring(index + this.versionSearchString.length + 1));
		},
		dataBrowser: [
			{
				string: navigator.userAgent,
				subString: "Chrome",
				identity: "Chrome"
			},
			{
				string: navigator.userAgent,
				subString: "OmniWeb",
				versionSearch: "OmniWeb/",
				identity: "OmniWeb"
			},
			{
				string: navigator.vendor,
				subString: "Apple",
				identity: "Safari",
				versionSearch: "Version"
			},
			{
				prop: window.opera,
				identity: "Opera",
				versionSearch: "Version"
			},
			{
				string: navigator.vendor,
				subString: "iCab",
				identity: "iCab"
			},
			{
				string: navigator.vendor,
				subString: "KDE",
				identity: "Konqueror"
			},
			{
				string: navigator.userAgent,
				subString: "Firefox",
				identity: "Firefox"
			},
			{
				string: navigator.vendor,
				subString: "Camino",
				identity: "Camino"
			},
			{		// for newer Netscapes (6+)
				string: navigator.userAgent,
				subString: "Netscape",
				identity: "Netscape"
			},
			{
				string: navigator.userAgent,
				subString: "MSIE",
				identity: "Explorer",
				versionSearch: "MSIE"
			},
			{
				string: navigator.userAgent,
				subString: "Gecko",
				identity: "Mozilla",
				versionSearch: "rv"
			},
			{ 		// for older Netscapes (4-)
				string: navigator.userAgent,
				subString: "Mozilla",
				identity: "Netscape",
				versionSearch: "Mozilla"
			}
		],
		dataOS: [
			{
				string: navigator.platform,
				subString: "Win",
				identity: "Windows"
			},
			{
				string: navigator.platform,
				subString: "Mac",
				identity: "Mac"
			},
			{
				string: navigator.userAgent,
				subString: "iPhone",
				identity: "iPhone/iPod"
			},
			{
				string: navigator.platform,
				subString: "Linux",
				identity: "Linux"
			}
		]

	};
	BrowserDetect.init();

	if (jQuery.tourTip) {
		return;
	}

	publicMethod = jQuery.fn[tourTip] = jQuery[tourTip] = function (options) {
		var settings = options;
		if (this.length > 0) {
			this.each(function (i, obj) {
				tourTipObjects.push({
					tipObject: obj,
					tipSettings: settings,
					tipProperties: setProperties(obj)
				});
			});
		} else {
			tourTipObjects.push({
				tipObject: this[0],
				tipSettings: settings,
				tipProperties: setProperties(this[0])
			});
		}
		return tourTipObjects;
	};

	publicMethod.create = function (options) {
		var settings = options;
		tourTipObjects.push({
			tipObject: undefined,
			tipSettings: settings,
			tipProperties: setProperties(undefined)
		});
	}

	function setSettings(options) {
		var settings = jQuery.extend({
			parentScroll: jQuery('html, body'),
			title: '',
			description: '',
			position: 'bottom',
			externalContent: undefined,
			externalContentHtml: '',
			closeIcon: true,
			nextButtonText: 'Next',
			previousButtonText: 'Previous',
			closeButtonText: 'Close',
			next: true,
			previous: false,
			close: false,
			width: window.outerWidth < 320 ? (window.outerWidth - 20)+'px' : '300px',
			height: 'auto',
			autoNextInterval: 0,//Todo: New Feature
			repeatIcon: false,//Todo: New Feature
			animation: 'fade',
			smoothScroll: true,

			//Events:
			onShow: false,
			onHide: false,
			onClose: false,
			onNext: false,
			onPrevious: false,
			onStart: false
		}, options);

		return settings;
	}

	publicMethod.start = function (generalOptions) {
		if (tourTipObjects.length > 0) {
			tourTipGeneralSettings = jQuery.extend({}, generalOptions);
			trigger(tourTipGeneralSettings.onStart);
			initializeDisabledArea();
			initializeTourTips();
			showDisabledArea();
			// hideDisabledArea();
			showTip(tourTipCurrentIndex > -1 ? tourTipCurrentIndex+1 : 0);
		}
	};

	publicMethod.next = function () {
		trigger(tourTipObjects[tourTipCurrentIndex].tipSettings.onNext,
			function () {
				showTip(tourTipCurrentIndex + 1);
			});
	}

	publicMethod.previous = function () {
		trigger(tourTipObjects[tourTipCurrentIndex].tipSettings.onPrevious,
			function () {
				showTip(tourTipCurrentIndex - 1);
			});
	}

	publicMethod.close = function () {
		hideTip();
		trigger(tourTipObjects[tourTipCurrentIndex].tipSettings.onClose);
		clearTourTipElements();
		finishTutorialFirstDisplay(function(){
			// tourTipObjects.shift();
		});
	}

	function setProperties(obj) {
		return { isFree: typeof (obj) == 'undefined' };
	}

	function initializeTourTips () {
		jQuery(tourTipObjects).each(function (i, obj) {
			var position;
			var specialClasses = '';
			var specialContentClasses = '';
			var nubClass = ' TourTipBottomNub';

			var setting = setSettings({});
			setting = jQuery.extend(setting, tourTipGeneralSettings);
			obj.tipSettings = jQuery.extend(setting, obj.tipSettings);

			if (obj.tipProperties.isFree) {
				specialClasses = ' FreeTourTip';
				specialContentClasses = ' FreeContentTourTip';
				position = 'fixed';
			}
			else if (jQuery(obj.tipObject).css('position') == 'fixed')
				position = 'fixed'
			else if (!obj.tipSettings.parentScroll.is('body') && obj.tipSettings.parentScroll.css('position') == 'fixed')
				position = 'fixed';
			else
				position = 'absolute'

			switch (obj.tipSettings.position) {
				case 'top':
					nubClass = ' TourTipTopNub';
					break;

				case 'left':
					nubClass = ' TourTipLeftNub';
					break;

				case 'right':
					nubClass = ' TourTipRightNub';
					break;
			}

			var coverContent = '<div class="TourTipCover TourTipTransitOpacity" id="TourTipCover' + i.toString() + '" style="position: ' + position + ';"></div>';
			var content = '<div class="TourTip TourTipTransitOpacity' + specialClasses + '" id="TourTip' + i.toString() + '" style="position: ' + position + ';">';

			if (obj.tipSettings.closeIcon == true)
				content += '<button type="button" class="pum-close popmake-close" onclick="jQuery.tourTip.close();">×</button>';

			content += '<div class="TourTipContent' + specialContentClasses + '" style="width: ' + obj.tipSettings.width + ';height: ' + obj.tipSettings.height + ';">';
			content += '<p class="TourTipTitle">' + obj.tipSettings.title + '</p>';
			content += '<p class="TourTipDesc">' + obj.tipSettings.description + '</p>';

			if (obj.tipSettings.externalContentHtml.length > 0)
				content += '<div class="TourTipExternalContent">' + obj.tipSettings.externalContentHtml + '</div>';
			else if (obj.tipSettings.externalContent != undefined)
				content += '<div class="TourTipExternalContent">' + obj.tipSettings.externalContent.html() + '</div>';

			if (!obj.tipProperties.isFree)
				content += '<div class="TourTipNub' + nubClass + '"></div>';

			content += generateButtonsContent(i);
			content += '</div></div>';
			jQuery('body').append(content);

			if (!obj.tipProperties.isFree)
				jQuery('body').append(coverContent);

			tourTipCurrentIndex = i;
			setTourTipPosition(true);
		});
		var tourTipVars = localStorage.getItem('tourtip-vars');
		if (tourTipVars != null) {
			var tourTipVarsParsed = JSON.parse(tourTipVars);
			tourTipCurrentIndex = parseInt(tourTipVarsParsed['tourtip-current-index']);
		} else tourTipCurrentIndex = -1;
	}

	function generateButtonsContent(index) {
		var content = '<div class="TourTipButtonsHolder">';
		if (index > 0 && tourTipObjects[index].tipSettings.previous == true)
			content += '<button class="TourTipButton TourTipPreviousButton" onclick="jQuery.tourTip.previous();">' +
				tourTipObjects[index].tipSettings.previousButtonText +
				'</button>';
		if (index < tourTipObjects.length && tourTipObjects[index].tipSettings.next == true)
			content += '<button class="TourTipButton TourTipNextButton" onclick="jQuery.tourTip.next();">' +
				tourTipObjects[index].tipSettings.nextButtonText +
				'</button>';
		if (tourTipObjects[index].tipSettings.close == true)
			content += '<button class="TourTipButton TourTipCloseButton" onclick="jQuery.tourTip.close();">' +
				tourTipObjects[index].tipSettings.closeButtonText +
				'</button>';

		content += '</div>';
		return content;
	}

	function clearTourTipElements() {
		jQuery('.TourTip').remove();
		jQuery('.TourTipDisabledArea').remove();
		tourTipCurrentIndex = -1;
	}

	function trigger(callback, onComplete) {
		onComplete = (onComplete === undefined) ? function(){} : onComplete;
		// was: callback.call(undefined, currentTourTip());
		if (jQuery.isFunction(callback)) {
			callback.call(onComplete, currentTourTip());
		}
	}

	function showTip(index) {
		if (index >= 0 && index < tourTipObjects.length && tourTipCurrentIndex != index) {
			hideTip();

			tourTipCurrentIndex = index;
			trigger(tourTipObjects[index].tipSettings.onShow);

			visibility(false, index, false);
			jQuery('#TourTip' + index.toString()).css('display', 'block');

			if (!tourTipObjects[index].tipProperties.isFree)
				jQuery('#TourTipCover' + index.toString()).css('display', 'block');

			setTourTipPosition();
		}
	}

	function hideTip() {
		if (tourTipCurrentIndex >= 0) {
			trigger(tourTipObjects[tourTipCurrentIndex].tipSettings.onHide);
			visibility(false, tourTipCurrentIndex, true);
		}
	}

	function currentTourTip() {
		return jQuery('#TourTip' + tourTipCurrentIndex.toString());
	}

	function currentTourTipCover() {
		if (!tourTipObjects[tourTipCurrentIndex].tipProperties.isFree)
			return jQuery('#TourTipCover' + tourTipCurrentIndex.toString());
		else
			return undefined;
	}

	function finalizeTourTipPosition(initialize) {
		var obj = currentTourTip();
		var coverObj = currentTourTipCover();
		var tipObj = jQuery(tourTipObjects[tourTipCurrentIndex].tipObject);
		var tipSetting = tourTipObjects[tourTipCurrentIndex].tipSettings;
		var currentPosition = tipSetting.position;
		var ignoreScroll = jQuery(tipObj).css('position') == 'fixed' ||
			jQuery(tipObj).parent().css('position') == 'fixed' ||
			tipSetting.parentScroll.css('position') == 'fixed';

		if (!tourTipObjects[tourTipCurrentIndex].tipProperties.isFree) {
			if (currentPosition == 'top') {
				if (window.outerWidth-obj.outerWidth()<obj.outerWidth()) {
					obj.css('left', ((window.outerWidth-obj.outerWidth())/2)+'px');
				} else {
					obj.css('left', tipObj.offset().left - (ignoreScroll ? jQuery(document).scrollLeft() : 0));
				}
				if (window.outerWidth-obj.outerWidth()<obj.outerWidth()) {
					jQuery('.TourTipTopNub').css('left', tipObj.offset().left - (ignoreScroll ? jQuery(document).scrollLeft() : 0));
				} else {
					jQuery('.TourTipTopNub').css('left', '20px');
				}
				obj.css('top', tipObj.offset().top - (ignoreScroll ? jQuery(document).scrollTop() : 0) - obj.outerHeight() - 10);
			}
			else if (currentPosition == 'left') {
				obj.css('left', tipObj.offset().left - (ignoreScroll ? jQuery(document).scrollLeft() : 0) - obj.width() - 10);
				obj.css('top', tipObj.offset().top - (ignoreScroll ? jQuery(document).scrollTop() : 0));
			}
			else if (currentPosition == 'right') {
				obj.css('left', tipObj.offset().left - (ignoreScroll ? jQuery(document).scrollLeft() : 0) + tipObj.outerWidth() + 10);
				obj.css('top', tipObj.offset().top - (ignoreScroll ? jQuery(document).scrollTop() : 0));
			}
			else {
				if (detectMob()) {
					obj.css('left', ((window.outerWidth-obj.outerWidth())/2)+'px');
					jQuery('.TourTipBottomNub').css('left', (obj.outerWidth()/2)+'px');
				} else {
					if (tourTipCurrentIndex == 7) {
						obj.css('left', tipObj.offset().left 
						- (ignoreScroll ? jQuery(document).scrollLeft() : 0) - 20);
						jQuery('.TourTipBottomNub').css('left', '45px');
					} else if (tourTipCurrentIndex == 9) {
						obj.css('left', tipObj.offset().left 
						- (ignoreScroll ? jQuery(document).scrollLeft() : 0) - (obj.outerWidth()/2));
						jQuery('.TourTipBottomNub').css('left', obj.outerWidth() - 100);
					} else if (tourTipCurrentIndex == 0) {
						obj.css('left', tipObj.offset().left + (tipObj.outerWidth()/2+20)
						- (ignoreScroll ? jQuery(document).scrollRight() : 0) - (obj.outerWidth()));
						jQuery('.TourTipBottomNub').css('left', obj.outerWidth() - 30);
					} else {
						obj.css('left', tipObj.offset().left - (ignoreScroll ? jQuery(document).scrollLeft() : 0));
						jQuery('.TourTipBottomNub').css('left', '20px');
					}
				}
				obj.css('top', tipObj.offset().top - (ignoreScroll ? jQuery(document).scrollTop() : 0) + tipObj.outerHeight() + 10);
			}

			// coverObj.css('left', tipObj.offset().left - (ignoreScroll ? jQuery(document).scrollLeft() : 0));
			// coverObj.css('top', tipObj.offset().top - (ignoreScroll ? jQuery(document).scrollTop() : 0));
			// coverObj.css('width', tipObj.outerWidth());
			// coverObj.css('height', tipObj.outerHeight());

			// var ctx = jQuery('#TourTipDisabledArea').get(0).getContext('2d');
			// ctx.clearRect(0, 0, jQuery('#TourTipDisabledArea').width(), jQuery('#TourTipDisabledArea').height());
			// ctx.globalCompositeOperation = "source-over";
			
			// ctx.fillStyle = "#FFFFFF";
			// ctx.globalCompositeOperation = "source-over";
			// if (coverObj.offset().top != 0) {
			// 	if (fhpc_isAnyParentFixed(coverObj) || coverObj.css('position') == 'fixed') {
			// 		ctx.fillRect(coverObj.offset().left, coverObj.offset().top - coverObj.scrollTop(), coverObj.outerWidth(), coverObj.outerHeight());
			// 	} else {
			// 		ctx.fillRect(coverObj.offset().left, coverObj.offset().top, coverObj.outerWidth(), coverObj.outerHeight());
			// 	}
			// }
			// ctx.globalCompositeOperation = "source-out";

			// // ctx.fillStyle = "#000000";
			// ctx.fillStyle = "rgba(128, 128, 128, .5)";

			// ctx.fillRect(0, 0, jQuery('#TourTipDisabledArea').width(), jQuery('#TourTipDisabledArea').height());
		}
		else {
			setFreePosition();
		}

		if (!initialize)
			visibility(true, tourTipCurrentIndex, true);
	}

	function visibility(visible, index, animate) {
		var isFreeTourTip = tourTipObjects[index].tipProperties.isFree;
		var animationVal = tourTipObjects[index].tipSettings.animation;

		if (visible) {
			switch (animationVal) {
				case 'none':
					break;

				case 'fade':
				default:
					jQuery('#TourTip' + index.toString()).css('opacity', '1');

					if (!isFreeTourTip){
						jQuery('#TourTipCover' + index.toString()).css('opacity', '0');
						jQuery('#TourTipCover' + index.toString()).css('border', '1px solid black');
					}
			}
		}
		else {
			switch (animationVal) {
				case 'none':
					break;

				case 'fade':
				default:
					jQuery('#TourTip' + index.toString()).css('opacity', '0');

					if (!isFreeTourTip) {
						jQuery('#TourTipCover' + index.toString()).css('opacity', '0');
					}
			}
			jQuery('#TourTip' + index.toString()).css('display', 'none');
			jQuery('#TourTipCover' + index.toString()).css('display', 'none');
		}
	}

	function setTourTipPosition(initialize) {
		initialize = typeof initialize != 'undefined' ? initialize : false;
		var tipObj = jQuery(tourTipObjects[tourTipCurrentIndex].tipObject);
		if (!initialize) {
			if (tourTipObjects[tourTipCurrentIndex].tipProperties.isFree)
				setFreePosition();
			else
				scrollIntoView();

			var wait = setInterval(function () {
				if (!jQuery(tipObj).parents().is(":animated") && !jQuery(tipObj).is(":animated")) {
					clearInterval(wait);
					finalizeTourTipPosition();
				}
			}, 200);
		}
		else {
			finalizeTourTipPosition(initialize);
		}
	}

	function setFreePosition() {
		centralize(currentTourTip());
	}

	function isCurrentTourTipFree() {
		return tourTipCurrentIndex != -1 && tourTipObjects[tourTipCurrentIndex].tipProperties.isFree;
	}

	function centralize(element) {
		element.css('left', jQuery(window).width() / 2 - (element.outerWidth() / 2));
		element.css('top', jQuery(window).height() / 2 - (element.outerHeight() / 2));
	}

	function switchBodyElement(element) {
		if (BrowserDetect.browser == 'Firefox' ||
			BrowserDetect.browser == 'Mozilla' ||
			BrowserDetect.browser == 'Explorer')
			return jQuery('html, body');
		else
			return element;
	}

	function scrollParentsIntoView() {
		var parentObj;
		var tipObj = jQuery(tourTipObjects[tourTipCurrentIndex].tipObject);
		var self = jQuery(tourTipObjects[tourTipCurrentIndex].tipSettings.parentScroll);
		var objParents = new Array(self);
		var animationVal = tourTipObjects[tourTipCurrentIndex].tipSettings.animation;

		self.parents().each(function (i, obj) { objParents.push(obj); });

		for (var i = 0; i < objParents.length; i++) {
			obj = objParents[i];
			parentObj = jQuery(obj).parent();

			if (i < objParents.length - 2 && jQuery(obj).css('position') != 'fixed' && parentObj.length > 0) {
				if (parentObj.is('body') || parentObj.is('html')) {
					parentObj = switchBodyElement(parentObj);
					if (animationVal == 'none') {
						parentObj.scrollTop(jQuery(obj).position().top - 20 + marginTop(jQuery(obj)));
						parentObj.scrollLeft(jQuery(obj).position().left - 20 + marginLeft(jQuery(obj)));
					}
					else {
						parentObj.animate(
							{
								scrollTop: jQuery(obj).position().top - 20 + marginTop(jQuery(obj)),
								scrollLeft: jQuery(obj).position().left - 20 + marginLeft(jQuery(obj))
							}
						);
					}
				}
				else {
					if (animationVal == 'none') {
						parentObj.scrollTop(jQuery(obj).position().top - 20 + marginTop(jQuery(obj)));
						parentObj.scrollLeft(jQuery(obj).position().left - 20 + marginLeft(jQuery(obj)));
					}
					else {
						parentObj.animate(
							{
								scrollTop: jQuery(obj).position().top - 20 + marginTop(jQuery(obj)),
								scrollLeft: jQuery(obj).position().left - 20 + marginLeft(jQuery(obj))
							}
						);
					}
				}
			}

			if (jQuery(obj).css('position') == 'fixed')
				return false;
		};
	}

	function scrollIntoView() {
		var tipObj = jQuery(tourTipObjects[tourTipCurrentIndex].tipObject);
		var tipSetting = tourTipObjects[tourTipCurrentIndex].tipSettings;
		var parentObj;
		var parents = tipObj.parents();
		var smooth = tipSetting.smoothScroll;

		if (tipObj.css('position') != 'fixed') {
			scrollParentsIntoView();

			var currentPosition = tipObj.position();
			parentObj = tipSetting.parentScroll;
			if (parentObj.is('body') || parentObj.is('html')) {
				parentObj = switchBodyElement(parentObj);
				var additionalBottom = tipSetting.position != 'bottom' ? 0 : currentTourTip().outerHeight();
				var additionalRight = tipSetting.position != 'right' ? 0 : currentTourTip().outerWidth();
				if (tipSetting.position == 'top') {
					if (currentPosition.top + marginTop(tipObj) - currentTourTip().outerHeight() < parentObj.scrollTop() ||
						currentPosition.top + tipObj.outerHeight() - marginBottom(tipObj) + additionalBottom > jQuery(window).height()) {
						if (smooth == false) {
							parentObj.scrollTop(currentPosition.top - 5 - currentTourTip().outerHeight());
						}
						else {
							parentObj.animate({ scrollTop: currentPosition.top - 5 - currentTourTip().outerHeight() });
						}
					}
				}
				else {
					if (currentPosition.top + marginTop(tipObj) < parentObj.scrollTop() ||
						currentPosition.top + tipObj.outerHeight() - marginBottom(tipObj) + additionalBottom > jQuery(window).height()) {
						if (smooth == false) {
							parentObj.scrollTop(currentPosition.top - 20 + marginTop(tipObj));
						}
						else {
							parentObj.animate({ scrollTop: currentPosition.top - 20 + marginTop(tipObj) });
						}
					}
				}

				if (currentPosition.left + marginLeft(tipObj) < parentObj.scrollLeft() ||
					currentPosition.left + tipObj.outerWidth() - marginRight(tipObj) + additionalRight > jQuery(window).width()) {
					if (smooth == false) {
						parentObj.scrollLeft(currentPosition.left - 20 + marginLeft(tipObj));
					}
					else {
						parentObj.animate({ scrollLeft: currentPosition.left - 20 + marginLeft(tipObj) });
					}
				}
			}
			else {
				if (tipSetting.position == 'top') {
					if (currentPosition.top + marginTop(tipObj) < 0 ||
						currentPosition.top + tipObj.outerHeight() - marginBottom(tipObj) > parentObj.outerHeight()) {
						if (smooth == false) {
							parentObj.scrollTop(currentPosition.top - 5 - currentTourTip().outerHeight());
						}
						else {
							parentObj.animate({ scrollTop: currentPosition.top - 5 - currentTourTip().outerHeight() });
						}
					}
				}
				else {
					if (currentPosition.top + marginTop(tipObj) < parentObj.scrollTop() ||
						currentPosition.top + tipObj.outerHeight() - marginBottom(tipObj) + parentObj.scrollTop() > parentObj.outerHeight()) {
						if (smooth == false) {
							parentObj.scrollTop(currentPosition.top - 20 + marginTop(tipObj) + parentObj.scrollTop());
						}
						else {
							parentObj.animate({ scrollTop: currentPosition.top - 20 + marginTop(tipObj) + parentObj.scrollTop() });
						}
					}
				}

				if (currentPosition.left + marginLeft(tipObj) < parentObj.scrollLeft() ||
					currentPosition.left + tipObj.outerWidth() - marginRight(tipObj) + parentObj.scrollLeft() > parentObj.outerWidth()) {
					if (smooth == false) {
						parentObj.scrollLeft(currentPosition.left - 20 + marginLeft(tipObj) + parentObj.scrollLeft());
					}
					else {
						parentObj.animate({ scrollLeft: currentPosition.left - 20 + marginLeft(tipObj) + parentObj.scrollLeft() });
					}
				}
			}
		}
	}

	function initializeDisabledArea () {
		jQuery('body').append('<canvas id="TourTipDisabledArea" width="0" height="0" class="TourTipDisabledArea"></canvas>');
		var initialOuterWidth = jQuery(document).outerWidth();
		jQuery(window).resize(function () {
			var docOuterWidth = jQuery(document).outerWidth();
			jQuery('.TourTipDisabledArea').attr({
				width: docOuterWidth == (initialOuterWidth + 17) ? docOuterWidth-17 : docOuterWidth,
				height: jQuery(document).outerHeight()
			}).css({
				width: docOuterWidth == (initialOuterWidth + 17) ? docOuterWidth-17 : docOuterWidth,
				height: jQuery(document).outerHeight()
			});
		}).resize();
	}

	function showDisabledArea() {
		jQuery('.TourTipDisabledArea').css('display', 'block');
	}

	function hideDisabledArea() {
		jQuery('.TourTipDisabledArea').css('display', 'none');
	}

	function marginLeft(element) {
		return parseInt(jQuery(element).css("margin-left").replace('px', ''), 10);
	}

	function marginRight(element) {
		return parseInt(jQuery(element).css("margin-right").replace('px', ''), 10);
	}

	function marginTop(element) {
		return parseInt(element.css("margin-top").replace('px', ''), 10);
	}

	function marginBottom(element) {
		return parseInt(jQuery(element).css("margin-bottom").replace('px', ''), 10);
	}

	jQuery(window).resize(function () {
		if (isCurrentTourTipFree())
			centralize(currentTourTip());
		if (tourTipCurrentIndex != -1) setTourTipPosition(true);
	});
}(jQuery, document, window));