jQuery(document).ready(function () {
    for (let i = 1; i <= 5; i++) {   
        handleSortable(i);     
    }
    initTourTipSteps();
    showTourStep();
    
    const isOpenPopup = localStorage.getItem("popupOpen");
    if (isOpenPopup == "fourth") {
        localStorage.removeItem("popupOpen");
        incrementFoundBugsCount(jQuery(this), "fourth", function () {
            loadPopUpImageAndGif("fourth", true);
            popupOpenAndClose(4406, function () {
                tooltipBugCountInfo();
                showHintIfBugsAreNearby("fourth");
            });
        });
    }
    resizeBugCounterTooltip();
    if (isFindYourOwnBugsModeOn()) {
        jQuery(".sfm-button:first-of-type").css("visibility", 'visible');
        tooltipBugCountInfo();
    }
    if (window.location.href.indexOf("https://academybugs.com/product/") >= 0) {
        jQuery("#wpmenucartli").removeClass('empty-wpmenucart');
        jQuery("#wpmenucartli").css({ "display": "list-item" });
    }
    if (window.location.href.indexOf("https://academybugs.com/report-bugs/") >= 0) {
        if (localStorage.getItem('bug-report') != null) {
            var bugReport = localStorage.getItem('bug-report');
            var parsedData = JSON.parse(bugReport);
            if (Object.keys(parsedData).length > 0) {
                for (let bugKey in parsedData) {
                    if (parsedData.hasOwnProperty(bugKey)) {
                        showReportResult(bugKey, bugReport);
                    }
                }
            }
            showScoreCounter(true, 1);
        }
        preload(1);
        storeBugReportForm(1);
        enableTabsIfScoreCounterExists('all');
        if (window.innerWidth < 480) {
            jQuery('.selectpicker').append('<optgroup label=""></optgroup>');
        }
    }

    switch (window.location.href) {
        case "https://academybugs.com":
        case "https://academybugs.com/":
        case "https://academybugs.com/#/":
            var firstDisplay = localStorage.getItem("tutorial-first-display");
            if (firstDisplay == undefined) jQuery.tourTip.start();
            break;
        case "https://academybugs.com/find-bugs/":
        case "https://academybugs.com/find-bugs/#":
            jQuery("#ec_product_image_effect_4281370 "
                + ".ec_product_image_display_type img")
                .attr("style", "padding-right: 30px");
            // Academy Bug 6
            break;
        case "https://academybugs.com/store/all-items/":
            if (window.innerWidth < 989) {
                var new_height = 310;
                if (window.innerWidth > 767) {
                    new_height = 310;
                } else if (window.innerWidth > 480) {
                    new_height = 380;
                } else {
                    new_height = 270;
                }
                if (window.location.href == "https://academybugs.com/store/all-items/" && window.innerWidth < 989) {
                    new_height = parseInt(new_height) + 140;
                }
                jQuery('.ec_image_container_none, .ec_image_container_border, .ec_image_container_shadow, .ec_image_container_none > div, .ec_image_container_border > div, .ec_image_container_shadow > div').css('min-height', new_height + 'px').css('height', new_height + 'px');
            }
            break;
        case "https://academybugs.com/report-bugs-results/":
            fillReportBugsResults();
            break;
        case 'https://academybugs.com/store/dnk-yellow-shoes/?single':
            jQuery(".ec_search_widget > form").attr("action", "test");
            localStorage.removeItem('example-5');
        case "https://academybugs.com/store/blue-tshirt/?single":
            jQuery('.ec_cart_widget_minicart_checkout_button').text("revisa");
            break;
        case "https://academybugs.com/latest-news/":
            // Causing the two videos to show black screen for the third bug in Examples of Bugs
            jQuery(".videonews-tile-div-academy-bug .plyr__video-wrapper video").attr("src", "");
            break;
        default:
            break;
    }
    addModal();

        
    if (localStorage.getItem("manufacturer-bug") != null) {
        console.log("404 page");
        loadPopUpImageAndGif("third", true);
        popupOpenAndClose(4406, function () {
            tooltipBugCountInfo();
            showHintIfBugsAreNearby("third", function () {
                localStorage.removeItem('manufacturer-bug');
            });
        });
    }
});

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
    return false;
};

function addModal() {
    if (location.href.indexOf('academybugs.com/docs')>-1) {
        jQuery('body').append('<div id="my-report-bugs-modal" class="report-bugs-modal">'
        +'<!-- The Close Button -->'
        +'<span class="report-bugs-modal-close">&times;</span>'
        +'<!-- Modal Content (The Image) -->'
        +'<img class="report-bugs-modal-content" id="img01">'
        +'<!-- Modal Caption (Image Text) -->'
        +'<div id="report-bugs-modal-caption"></div></div>');
    }
}
function finishTutorialFirstDisplay(onFirstTime) {
    onFirstTime = (onFirstTime === undefined) ? function(){} : onFirstTime;
    var firstDisplay = localStorage.getItem("tutorial-first-display");
    if (firstDisplay == undefined) {
        localStorage.setItem('tutorial-first-display', "finished");
        onFirstTime();
    }
}
function isTutorialDisplayingFirstTime() {
    var firstDisplay = localStorage.getItem("tutorial-first-display");
    return (firstDisplay == undefined);
}
function clearTourVars() {
    localStorage.removeItem('current-step');
    localStorage.removeItem('tourtip-vars');
}
function academyNavMenu(val) {
    if (!detectMob()) return;
    if (val == 'show') {
        if (jQuery('#sq-site-navigation').css('display') == 'none') 
        jQuery('#sq-site-navigation').slideToggle();
    } else {
        if (jQuery('#sq-site-navigation').css('display') != 'none') 
        jQuery('#sq-site-navigation').slideToggle();
    }
}
function initTourTipSteps() {
    jQuery("#menu-item-2363").tourTip({
        title: "Tutorial",
        description: "Click start to begin the guided site tutorial",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Start',
        previousButtonText: 'Previous',
        closeIcon: true,
        onShow: function() {
            academyNavMenu('show');
        },
        onNext: function() {
            if (["https://academybugs.com","https://academybugs.com/","https://academybugs.com/#/"]
            .indexOf(window.location.href)<0) {
                storeTourStepVars(0);
                localStorage.setItem('current-step', 'next');
                location = 'https://academybugs.com/';
            } else {
                this();
            }
        },
        onClose: function() {
            clearTourVars();
        }
    });
    jQuery("#menu-item-5906").tourTip({
        title: "Examples of Bugs",
        description: "Click here to see examples of real bugs",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        closeIcon: true,
        onPrevious: function() {
            this();
        },
        onShow: function() {
            academyNavMenu('show');
        },
        onNext: function() {
            academyNavMenu('hide');
            this();
        },
        onClose: function() {
            clearTourVars();
        }
    });
    jQuery("a.example-tile-div:nth-child(1)").tourTip({
        title: "Examples of Bugs",
        description: "Click these icons to open the examples",
        previous: true,
        next: true,
        position: 'top',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onPrevious: function() {
            this();
        },
        onNext: function() {
            loadExamplePopup(1);
            popupOpenAndCloseWithoutTitle(4434, function () {
                clearPopupAssetsFor("example");
            });
            this();
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery("#popmake-4434 .pum-content.popmake-content .type-popup-bug-steps").tourTip({
        title: "Examples of Bugs",
        description: "Follow the steps to recreate the bug",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onPrevious: function() {
            this();
        },
        onNext: function() {
            jQuery("#popmake-4434 .pum-close.popmake-close").click();
            this();
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery("#menu-item-1024").tourTip({
        title: "Types of Bugs",
        description: "Click here to see types of bugs",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onNext: function() {
            storeTourStepVars(4);
            localStorage.setItem('current-step', 'next');
            location = 'https://academybugs.com/types/';
        },
        onPrevious: function() {
            loadExamplePopup(1);
            popupOpenAndCloseWithoutTitle(4434, function () {
                clearPopupAssetsFor("example");
            });
            academyNavMenu('hide');
            this();
        },
        onShow: function() {
            academyNavMenu('show');
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery("a.types-of-bugs-tile-div:nth-child(1)").tourTip({
        title: "Types of Bugs",
        description: "Click these icons to learn about each type",
        previous: true,
        next: true,
        position: 'top',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onPrevious: function() {
            storeTourStepVars(3);
            localStorage.setItem('current-step', 'next');
            location = 'https://academybugs.com/';
        },
        onNext: function() {
            loadTypesPopup("functional");
            popupOpenAndCloseWithoutTitle(4454, function () {
                clearPopupAssetsFor("types-of-bugs");
            });
            this();
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery("#popmake-4454 .pum-content.popmake-content .examples-of-bugs-popup-steps").tourTip({
        title: "Types of Bugs",
        description: "Follow the steps to recreate the bug",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onPrevious: function() {
            this();
        },
        onNext: function() {
            jQuery("#popmake-4454 .pum-close.popmake-close").click();
            this();
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery("#menu-item-561").tourTip({
        title: "Find Bugs",
        description: "Click here to find bugs on your own",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onShow: function() {
            academyNavMenu('show');
        },
        onNext: function() {
            storeTourStepVars(7);
            localStorage.setItem('current-step', 'next');
            location = 'https://academybugs.com/find-bugs/';
        },
        onPrevious: function() {
            loadTypesPopup("functional");
            popupOpenAndCloseWithoutTitle(4454, function () {
                clearPopupAssetsFor("types-of-bugs");
            });
            academyNavMenu('hide');
            this();
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery.tourTip.create({
        title: "Find Bugs",
        description: "Explore this section and try to find 20 bugs",
        previous: true,
        next: true,
        position: 'top',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onNext: function() {
            this();
        },
        onPrevious: function() {
            storeTourStepVars(6);
            localStorage.setItem('current-step', 'next');
            location = 'https://academybugs.com/types/';
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery("#menu-item-5687").tourTip({
        title: "Report Bugs",
        description: "Click here to practice creating bug reports",
        previous: true,
        next: true,
        position: 'bottom',
        nextButtonText: 'Next',
        previousButtonText: 'Previous',
        onShow: function() {
            academyNavMenu('show');
        },
        onNext: function() {
            storeTourStepVars(9);
            localStorage.setItem('current-step', 'next');
            location = 'https://academybugs.com/report-bugs/';
        },
        onPrevious: function() {
            academyNavMenu('hide');
            this();
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
    jQuery.tourTip.create({
        title: "Report Bugs",
        description: "Practice creating bug reports",
        previous: true,
        next: true,
        position: 'top',
        nextButtonText: 'Done',
        previousButtonText: 'Previous',
        onNext: function() {
            jQuery.tourTip.close();
            location = 'https://academybugs.com';
        },
        onPrevious: function() {
            storeTourStepVars(8);
            localStorage.setItem('current-step', 'next');
            location = 'https://academybugs.com/find-bugs/';
        },
        onClose: function() {
            clearTourVars();
        },
        closeIcon: true
    });
}
var tourTip, tourTipCurrentIndex;
function showTourStep() {
    var currentStep = localStorage.getItem('current-step');
    if (currentStep == 'next') jQuery.tourTip.start();
}
function storeTourStepVars(tourTipCurrentIndex) {
    var tourTipVars = {};
    tourTipVars['tourtip'] = tourTip;
    tourTipVars['tourtip-current-index'] = tourTipCurrentIndex;
    localStorage.setItem('tourtip-vars', JSON.stringify(tourTipVars));
}
function handleSortable(bugIndex) {
    var sortable1Id = "bug-" + bugIndex + "-sortable-1";
    var sortable2Id = "bug-" + bugIndex + "-sortable-2";
    var actionPerformedPlaceholder = ".bug-" + bugIndex + "-action-performed-placeholder";
    var stepNumber = '.bug-' + bugIndex + '-step-number';
    var actionPerformedLi = '.bug-' + bugIndex + '-step-li';
    var stepText = '.bug-' + bugIndex + '-step-text';
    var connectedSortable = '.bug' + bugIndex + 'ConnectedSortable';
    var oldList, newList, item;
    jQuery("#" + sortable1Id + ", " + "#" + sortable2Id).sortable({
        connectWith: connectedSortable,
        start: function (event, ui) {
            item = ui.item;
            newList = oldList = ui.item.parent();
        },
        stop: function (event, ui) {
            jQuery(actionPerformedPlaceholder).css("display", 
            jQuery("#" + sortable1Id).children().length == 0 ? 'block' : 'none');

            item.find(stepNumber).css("display", 
            newList.attr('id') == sortable1Id ? 'inline' : 'none');

            jQuery(actionPerformedLi).each(function (index, li) {
                if (jQuery(li).parents("#" + sortable1Id).length > 0) {
                    jQuery(li).find(stepNumber).html((index + 1) + ". ");
                    jQuery(li).find("input[type='text']").attr("name", "bug-step-" + bugIndex + "[]");
                    // jQuery(li).find("input[type='text']").val(jQuery(li).find(stepText).html());

                    var spanId = jQuery(li).find(stepText).attr('id');
                    var stepId = -1;
                    if (spanId && spanId.startsWith("bug-")) {
                      stepId = spanId.split("-").pop();
                    }
                    jQuery(li).find("input[type='text']").val(stepId);
                    
                } else {
                    jQuery(li).find("input[type='text']").attr("name", "bug-step-unnecessary");
                    // jQuery(li).find("input[type='text']").val(jQuery(li).find(stepText).html());
                    jQuery(li).find("input[type='text']").val(jQuery(li).find(stepText).attr('id'));
                }
            });
        },
        change: function (event, ui) {
            if (ui.sender) newList = ui.placeholder.parent();
        },
        update: function (event, ui) {
        }
    });
}
function resizeBugCounterTooltip() {
    if (isFindYourOwnBugsModeOn && window.innerWidth < 480) {
        jQuery(".sfm-tool-tip").width(window.innerWidth - 148);
        jQuery('.sfm-tool-tip>p').attr("style", "white-space: break-spaces; color: #262626; font-family: 'Open Sans', sans-serif; font-size: 16px; font-weight: 550; text-align: center; margin-top: 0.5em");
        jQuery('.sfm-tool-tip>.tooltip-table-container').attr("style", "overflow-y: auto; height: 200px; width: 100%; text-align: center; margin-bottom: 0");
    }
}
function detectMob() {
    return (window.innerWidth <= 900);
}
function isFindYourOwnBugsModeOn() {
    return (window.location.href.indexOf("https://academybugs.com/my-cart/") >= 0 ||
        window.location.href.indexOf("https://academybugs.com/find-bugs/") >= 0 ||
        window.location.href.indexOf("https://academybugs.com/store") >= 0 ||
        window.location.href.indexOf("https://academybugs.com/account") >= 0 ||
        window.location.href == "https://academybugs.com/anchor-bracelet/" ||
        window.location.href == "https://academybugs.com/myspace/");
}